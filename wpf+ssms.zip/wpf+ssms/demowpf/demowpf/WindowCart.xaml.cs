﻿using System.Windows;

namespace demowpf
{
    public partial class WindowCart : Window
    {
        public WindowCart()
        {
            InitializeComponent();
            dgv.ItemsSource = WindowCatalog.Cart.DefaultView;
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
            => WindowCatalog.Cart.Rows.Clear();
    }
}