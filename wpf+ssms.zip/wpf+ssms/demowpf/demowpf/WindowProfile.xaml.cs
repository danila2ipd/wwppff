﻿using System.Data.SqlClient;
using System.Windows;

namespace demowpf
{
    public partial class WindowProfile : Window
    {
        WindowCatalog parent;

        public WindowProfile(WindowCatalog p)
        {
            InitializeComponent();
            parent = p;
            lblLogin.Text = "Логин: " + App.UserLogin;
            lblRole.Text = "Роль: " + App.UserRole;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (txtPass.Password.Trim() == "") { MessageBox.Show("Введите новый пароль!"); return; }
            if (txtPass.Password.Length > 3) { MessageBox.Show("Пароль макс 3 символа!"); return; }
            var con = DB.Get(); con.Open();
            var cmd = new SqlCommand("UPDATE Users SET Password=@p WHERE Id=@id", con);
            cmd.Parameters.AddWithValue("@p", txtPass.Password);
            cmd.Parameters.AddWithValue("@id", App.UserId);
            cmd.ExecuteNonQuery(); con.Close();
            MessageBox.Show("Пароль изменён!");
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            App.UserId = 0;
            App.UserLogin = "";
            App.UserRole = "";
            parent.UpdateButtons();
            Close();
        }
    }
}