﻿using System.Data.SqlClient;
using System.Windows;

namespace demowpf
{
    public partial class WindowAuth : Window
    {
        public WindowAuth()
        {
            InitializeComponent();
        }

        bool Check()
        {
            if (txtLogin.Text.Trim() == "") { MessageBox.Show("Введите логин!"); return false; }
            if (txtPass.Password.Trim() == "") { MessageBox.Show("Введите пароль!"); return false; }
            if (txtPass.Password.Length > 3) { MessageBox.Show("Пароль макс 3 символа!"); return false; }
            return true;
        }

        private void btnVhod_Click(object sender, RoutedEventArgs e)
        {
            if (!Check()) return;
            var con = DB.Get(); con.Open();
            var cmd = new SqlCommand("SELECT * FROM Users WHERE Login=@l AND Password=@p", con);
            cmd.Parameters.AddWithValue("@l", txtLogin.Text);
            cmd.Parameters.AddWithValue("@p", txtPass.Password);
            var r = cmd.ExecuteReader();
            if (r.Read())
            {
                App.UserId = (int)r["Id"];
                App.UserLogin = r["Login"].ToString();
                App.UserRole = r["Role"].ToString();
                con.Close();
                new WindowCatalog().Show();
                Close();
            }
            else { con.Close(); MessageBox.Show("Неверный логин или пароль!"); }
        }

        private void btnReg_Click(object sender, RoutedEventArgs e)
        {
            if (!Check()) return;
            var con = DB.Get(); con.Open();
            var check = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Login=@l", con);
            check.Parameters.AddWithValue("@l", txtLogin.Text);
            if ((int)check.ExecuteScalar() > 0) { con.Close(); MessageBox.Show("Логин занят!"); return; }
            var cmd = new SqlCommand("INSERT INTO Users(Login,Password,Role) VALUES(@l,@p,'user')", con);
            cmd.Parameters.AddWithValue("@l", txtLogin.Text);
            cmd.Parameters.AddWithValue("@p", txtPass.Password);
            cmd.ExecuteNonQuery(); con.Close();
            MessageBox.Show("Готово! Теперь войдите.");
        }

        // Гость — просто открываем каталог без авторизации
        private void btnGuest_Click(object sender, RoutedEventArgs e)
        {
            new WindowCatalog().Show();
            Close();
        }
    }
}