using System.Windows;
using TechStore.Data;
using TechStore.Services;
using TechStore.Views;

namespace TechStore;

public partial class App : Application
{
    public static AuthService Auth { get; private set; } = null!;
    public static CategoryService Categories { get; private set; } = null!;
    public static ProductService Products { get; private set; } = null!;
    public static OrderService Orders { get; private set; } = null!;
    public static CartService Cart { get; private set; } = null!;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // Проверяем подключение к SQL Server
        var err = Database.TestConnection();
        if (err != null)
        {
            MessageBox.Show(
                $"Не удалось подключиться к SQL Server:\n\n{err}\n\n" +
                $"Проверьте строку подключения в StoreConfig.cs:\n" +
                $"{StoreConfig.ConnectionString}",
                "Ошибка подключения к БД",
                MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(1);
            return;
        }

        Auth = new AuthService();
        Categories = new CategoryService();
        Products = new ProductService();
        Orders = new OrderService();
        Cart = new CartService();

        // ── Сброс пароля администратора ──────────────────────
        // Генерируем хэш той же библиотекой BCrypt.Net-Next,
        // которая установлена в проекте — гарантированно совместимо.
        // После первого успешного входа эти строки можно удалить.
        try
        {
            var newHash = BCrypt.Net.BCrypt.HashPassword("admin123");
            Database.Exec(
                "UPDATE Users SET PasswordHash=@h WHERE Login='admin'",
                cmd => cmd.Parameters.AddWithValue("@h", newHash),
                isProc: false);
        }
        catch { /* если что-то пошло не так — просто продолжаем */ }
        // ─────────────────────────────────────────────────────

        new MainShopWindow().Show();
    }

    public static void OpenAdminPanel()
    {
        new LoginWindow().ShowDialog();
    }
}
