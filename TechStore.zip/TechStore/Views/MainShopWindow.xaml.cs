using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using TechStore.Models;

namespace TechStore.Views;

public partial class MainShopWindow : Window
{
    private int? _selectedCategoryId = null;
    private Button? _activeCatBtn;

    public MainShopWindow()
    {
        InitializeComponent();
        TxtStoreName.Text     = StoreConfig.StoreName;
        TxtStoreSubtitle.Text = StoreConfig.StoreSubtitle;

        App.Cart.CartChanged += UpdateCartBadge;
        UpdateCartBadge();
        BuildCategoryBar();
        LoadProducts();
    }

    // ─── Панель категорий ────────────────────────────────────
    private void BuildCategoryBar()
    {
        PanelCategories.Children.Clear();
        AddCatButton("Все товары", null);
        foreach (var cat in App.Categories.GetAll())
            AddCatButton(cat.Name, cat.Id);
    }

    private void AddCatButton(string text, int? catId)
    {
        var btn = new Button
        {
            Content          = text,
            Tag              = catId,
            Padding          = new Thickness(16, 10, 16, 10),
            Margin           = new Thickness(0, 0, 4, 0),
            Background       = Brushes.Transparent,
            BorderThickness  = new Thickness(0),
            FontFamily       = (FontFamily)FindResource("AppFont"),
            FontSize         = 13,
            Foreground       = (Brush)FindResource("TextPrimaryBrush"),
            Cursor           = System.Windows.Input.Cursors.Hand,
        };
        btn.Click += CatBtn_Click;
        if (catId == _selectedCategoryId)
            SetActiveCat(btn);
        PanelCategories.Children.Add(btn);
    }

    private void CatBtn_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button btn)
        {
            _selectedCategoryId = btn.Tag as int?;
            SetActiveCat(btn);
            LoadProducts();
        }
    }

    private void SetActiveCat(Button btn)
    {
        if (_activeCatBtn != null)
        {
            _activeCatBtn.Background = Brushes.Transparent;
            _activeCatBtn.Foreground = (Brush)FindResource("TextPrimaryBrush");
        }
        _activeCatBtn  = btn;
        btn.Background = (Brush)FindResource("PrimaryBrush");
        btn.Foreground = Brushes.White;
    }

    // ─── Загрузка и отображение товаров ─────────────────────
    private void LoadProducts()
    {
        var query    = TxtSearch.Text.Trim();
        var products = App.Products.Search(query, _selectedCategoryId);

        PanelProducts.Children.Clear();

        if (!products.Any())
        {
            PanelEmpty.Visibility    = Visibility.Visible;
            ScrollCatalog.Visibility = Visibility.Collapsed;
        }
        else
        {
            PanelEmpty.Visibility    = Visibility.Collapsed;
            ScrollCatalog.Visibility = Visibility.Visible;
            foreach (var p in products)
                PanelProducts.Children.Add(BuildProductCard(p));
        }

        TxtProductCount.Text = $"Показано товаров: {products.Count}";
    }

    // ─── Карточка товара ─────────────────────────────────────
    private FrameworkElement BuildProductCard(Product product)
    {
        var border = new Border
        {
            Width        = 220,
            Margin       = new Thickness(6),
            Background   = Brushes.White,
            CornerRadius = new CornerRadius(10),
            Cursor       = System.Windows.Input.Cursors.Hand,
        };
        border.Effect = new System.Windows.Media.Effects.DropShadowEffect
        {
            BlurRadius = 10, ShadowDepth = 2,
            Color = Colors.Black, Opacity = 0.08,
        };

        var stack = new StackPanel();

        // Изображение / заглушка
        var imgBorder = new Border
        {
            Height       = 150,
            Background   = new SolidColorBrush(Color.FromRgb(240, 244, 250)),
            CornerRadius = new CornerRadius(10, 10, 0, 0),
            ClipToBounds = true,
        };

        if (!string.IsNullOrEmpty(product.ImagePath) &&
            System.IO.File.Exists(product.ImagePath))
        {
            try
            {
                imgBorder.Child = new Image
                {
                    Source  = new BitmapImage(new Uri(product.ImagePath)),
                    Stretch = Stretch.UniformToFill,
                };
            }
            catch { imgBorder.Child = Placeholder(); }
        }
        else
        {
            imgBorder.Child = Placeholder();
        }
        stack.Children.Add(imgBorder);

        // Тело
        var body = new StackPanel { Margin = new Thickness(14, 12, 14, 14) };

        body.Children.Add(new TextBlock
        {
            Text       = product.CategoryName,
            FontFamily = (FontFamily)FindResource("AppFont"),
            FontSize   = 11,
            Foreground = (Brush)FindResource("TextSecBrush"),
            Margin     = new Thickness(0, 0, 0, 4),
        });

        body.Children.Add(new TextBlock
        {
            Text         = product.Name,
            FontFamily   = (FontFamily)FindResource("AppFont"),
            FontSize     = 13, FontWeight = FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            MaxHeight    = 42,
            Foreground   = (Brush)FindResource("TextPrimaryBrush"),
            Margin       = new Thickness(0, 0, 0, 8),
        });

        body.Children.Add(new TextBlock
        {
            Text       = product.PriceFormatted,
            FontFamily = (FontFamily)FindResource("AppFont"),
            FontSize   = 17, FontWeight = FontWeights.Bold,
            Foreground = (Brush)FindResource("PrimaryBrush"),
            Margin     = new Thickness(0, 0, 0, 6),
        });

        var stockBrush = product.Stock == 0
            ? (Brush)FindResource("DangerBrush")
            : product.LowStock
                ? (Brush)FindResource("WarningBrush")
                : (Brush)FindResource("SuccessBrush");

        body.Children.Add(new TextBlock
        {
            Text       = product.StockStatus,
            FontFamily = (FontFamily)FindResource("AppFont"),
            FontSize   = 11, Foreground = stockBrush,
            Margin     = new Thickness(0, 0, 0, 12),
        });

        // Кнопки
        var btnRow = new StackPanel { Orientation = Orientation.Horizontal };

        var btnCart = new Button
        {
            Content   = product.InStock ? "В корзину" : "Нет",
            Style     = (Style)FindResource("BtnPrimary"),
            FontSize  = 12, Padding = new Thickness(12, 6, 12, 6),
            IsEnabled = product.InStock,
        };
        btnCart.Click += (_, _) =>
        {
            App.Cart.Add(product);
            MessageBox.Show($"«{product.Name}» добавлен в корзину.",
                            "Корзина", MessageBoxButton.OK,
                            MessageBoxImage.Information);
        };
        btnRow.Children.Add(btnCart);

        var btnInfo = new Button
        {
            Content  = "ℹ",
            Style    = (Style)FindResource("BtnSecondary"),
            FontSize = 12, Padding = new Thickness(8, 6, 8, 6),
            Margin   = new Thickness(6, 0, 0, 0),
            ToolTip  = "Подробнее",
        };
        btnInfo.Click += (_, _) =>
        {
            var dlg = new ProductDetailWindow(product) { Owner = this };
            dlg.ShowDialog();
        };
        btnRow.Children.Add(btnInfo);
        body.Children.Add(btnRow);

        stack.Children.Add(body);
        border.Child = stack;
        return border;
    }

    private static UIElement Placeholder() => new TextBlock
    {
        Text = "🖼", FontSize = 42,
        HorizontalAlignment = HorizontalAlignment.Center,
        VerticalAlignment   = VerticalAlignment.Center,
        Opacity             = 0.25,
    };

    private void UpdateCartBadge()
    {
        Dispatcher.Invoke(() =>
        {
            var n             = App.Cart.Count;
            TxtCartCount.Text = n > 0 ? n.ToString() : "";
            CartBadge.Visibility = n > 0 ? Visibility.Visible : Visibility.Collapsed;
        });
    }

    private void TxtSearch_Changed(object sender, TextChangedEventArgs e) => LoadProducts();

    private void BtnCart_Click(object sender, RoutedEventArgs e)
    {
        var wnd = new CartWindow { Owner = this };
        wnd.ShowDialog();
        LoadProducts();
    }

    private void BtnAdmin_Click(object sender, RoutedEventArgs e) =>
        App.OpenAdminPanel();
}
