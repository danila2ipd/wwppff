using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using TechStore.Models;

namespace TechStore.Views;

/// <summary>Окно корзины.</summary>
public class CartWindow : Window
{
    private DataGrid? _grid;
    private TextBlock? _txtTotal;

    public CartWindow()
    {
        Title  = "Корзина";
        Width  = 640; Height = 500;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Background = (Brush)Application.Current.Resources["BgBrush"];
        BuildUI();
    }

    private void BuildUI()
    {
        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        // Шапка
        var header = new Border
        {
            Background = (Brush)Application.Current.Resources["PrimaryBrush"],
            Padding    = new Thickness(24, 14, 24, 14),
        };
        header.Child = new TextBlock
        {
            Text       = "🛒 Корзина",
            Foreground = Brushes.White,
            FontSize   = 16, FontWeight = FontWeights.Bold,
            FontFamily = (FontFamily)Application.Current.Resources["AppFont"],
        };
        Grid.SetRow(header, 0);
        root.Children.Add(header);

        // Таблица
        _grid = new DataGrid
        {
            Style  = (Style)Application.Current.Resources["AppDataGrid"],
            Margin = new Thickness(16, 16, 16, 0),
        };

        _grid.Columns.Add(new DataGridTextColumn
        {
            Header  = "Товар",
            Width   = new DataGridLength(1, DataGridLengthUnitType.Star),
            Binding = new System.Windows.Data.Binding("Product.Name"),
        });
        _grid.Columns.Add(new DataGridTextColumn
        {
            Header  = "Цена",
            Width   = new DataGridLength(120),
            Binding = new System.Windows.Data.Binding("Product.PriceFormatted"),
        });

        // Столбец кол-во с кнопками ±
        var qtyCol = new DataGridTemplateColumn
        {
            Header = "Кол-во",
            Width  = new DataGridLength(110),
        };
        var qtyFactory = new FrameworkElementFactory(typeof(StackPanel));
        qtyFactory.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);

        var btnMinus = new FrameworkElementFactory(typeof(Button));
        btnMinus.SetValue(Button.ContentProperty, "−");
        btnMinus.SetValue(Button.StyleProperty,
            Application.Current.Resources["BtnSmall"]);
        btnMinus.SetValue(Button.MarginProperty, new Thickness(0, 0, 4, 0));
        btnMinus.AddHandler(Button.ClickEvent,
            new RoutedEventHandler(BtnMinus_Click));

        var qtyLabel = new FrameworkElementFactory(typeof(TextBlock));
        qtyLabel.SetBinding(TextBlock.TextProperty,
            new System.Windows.Data.Binding("Quantity"));
        qtyLabel.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        qtyLabel.SetValue(TextBlock.MinWidthProperty, 24.0);
        qtyLabel.SetValue(TextBlock.TextAlignmentProperty, TextAlignment.Center);
        qtyLabel.SetValue(TextBlock.FontFamilyProperty,
            Application.Current.Resources["AppFont"]);

        var btnPlus = new FrameworkElementFactory(typeof(Button));
        btnPlus.SetValue(Button.ContentProperty, "+");
        btnPlus.SetValue(Button.StyleProperty,
            Application.Current.Resources["BtnSmall"]);
        btnPlus.SetValue(Button.MarginProperty, new Thickness(4, 0, 0, 0));
        btnPlus.AddHandler(Button.ClickEvent,
            new RoutedEventHandler(BtnPlus_Click));

        qtyFactory.AppendChild(btnMinus);
        qtyFactory.AppendChild(qtyLabel);
        qtyFactory.AppendChild(btnPlus);

        var qtyTemplate = new DataTemplate { VisualTree = qtyFactory };
        qtyCol.CellTemplate = qtyTemplate;
        _grid.Columns.Add(qtyCol);

        _grid.Columns.Add(new DataGridTextColumn
        {
            Header  = "Сумма",
            Width   = new DataGridLength(120),
            Binding = new System.Windows.Data.Binding("SubtotalFormatted"),
        });

        // Столбец Удалить
        var delCol = new DataGridTemplateColumn
        {
            Header = "",
            Width  = new DataGridLength(46),
        };
        var delFactory = new FrameworkElementFactory(typeof(Button));
        delFactory.SetValue(Button.ContentProperty, "✕");
        delFactory.SetValue(Button.StyleProperty,
            Application.Current.Resources["BtnSmall"]);
        delFactory.SetValue(Button.BackgroundProperty,
            Application.Current.Resources["DangerBrush"]);
        delFactory.AddHandler(Button.ClickEvent,
            new RoutedEventHandler(BtnRemove_Click));
        delCol.CellTemplate = new DataTemplate { VisualTree = delFactory };
        _grid.Columns.Add(delCol);

        RefreshGrid();
        Grid.SetRow(_grid, 1);
        root.Children.Add(_grid);

        // Нижняя панель
        var footer = new Border
        {
            Background      = Brushes.White,
            BorderBrush     = (Brush)Application.Current.Resources["BorderBrush"],
            BorderThickness = new Thickness(0, 1, 0, 0),
            Padding         = new Thickness(24, 14, 24, 16),
        };
        var footerGrid = new Grid();
        footerGrid.ColumnDefinitions.Add(
            new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        footerGrid.ColumnDefinitions.Add(
            new ColumnDefinition { Width = GridLength.Auto });

        _txtTotal = new TextBlock
        {
            FontFamily        = (FontFamily)Application.Current.Resources["AppFont"],
            FontSize          = 17, FontWeight = FontWeights.Bold,
            Foreground        = (Brush)Application.Current.Resources["TextPrimaryBrush"],
            VerticalAlignment = VerticalAlignment.Center,
        };
        UpdateTotal();
        Grid.SetColumn(_txtTotal, 0);
        footerGrid.Children.Add(_txtTotal);

        var btnCheckout = new Button
        {
            Content = "Оформить заказ →",
            Style   = (Style)Application.Current.Resources["BtnPrimary"],
        };
        btnCheckout.Click += BtnCheckout_Click;
        Grid.SetColumn(btnCheckout, 1);
        footerGrid.Children.Add(btnCheckout);

        footer.Child = footerGrid;
        Grid.SetRow(footer, 2);
        root.Children.Add(footer);

        Content = root;
    }

    private void RefreshGrid()
    {
        if (_grid == null) return;
        _grid.ItemsSource = null;
        _grid.ItemsSource = App.Cart.Items.ToList();
        UpdateTotal();
    }

    private void UpdateTotal()
    {
        if (_txtTotal == null) return;
        _txtTotal.Text = App.Cart.IsEmpty
            ? "Корзина пуста"
            : $"Итого: {App.Cart.TotalFormatted}";
    }

    private CartItem? GetItem(object sender)
    {
        if (sender is Button { DataContext: CartItem ci }) return ci;
        return _grid?.SelectedItem as CartItem;
    }

    private void BtnMinus_Click(object sender, RoutedEventArgs e)
    {
        var item = GetItem(sender);
        if (item == null) return;
        App.Cart.SetQuantity(item.Product.Id, item.Quantity - 1);
        RefreshGrid();
    }

    private void BtnPlus_Click(object sender, RoutedEventArgs e)
    {
        var item = GetItem(sender);
        if (item == null) return;
        App.Cart.SetQuantity(item.Product.Id, item.Quantity + 1);
        RefreshGrid();
    }

    private void BtnRemove_Click(object sender, RoutedEventArgs e)
    {
        var item = GetItem(sender);
        if (item == null) return;
        App.Cart.Remove(item.Product.Id);
        RefreshGrid();
    }

    private void BtnCheckout_Click(object sender, RoutedEventArgs e)
    {
        if (App.Cart.IsEmpty)
        {
            MessageBox.Show("Корзина пуста.", "Корзина",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var dlg = new CheckoutWindow { Owner = this };
        if (dlg.ShowDialog() == true)
        {
            App.Cart.Clear();
            RefreshGrid();
            Close();
        }
    }
}

// ─────────────────────────────────────────────────────────
// Окно оформления заказа
// ─────────────────────────────────────────────────────────
public class CheckoutWindow : Window
{
    private TextBox _txtName   = null!;
    private TextBox _txtPhone  = null!;
    private TextBox _txtEmail  = null!;
    private TextBox _txtAddr   = null!;
    private TextBox _txtComment= null!;

    public CheckoutWindow()
    {
        Title  = "Оформление заказа";
        Width  = 460; Height = 510;
        ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Background = (Brush)Application.Current.Resources["BgBrush"];
        BuildUI();
    }

    private void BuildUI()
    {
        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        // Шапка
        var header = new Border
        {
            Background = (Brush)Application.Current.Resources["PrimaryBrush"],
            Padding    = new Thickness(24, 14, 24, 14),
        };
        header.Child = new TextBlock
        {
            Text       = "Оформление заказа",
            Foreground = Brushes.White,
            FontSize   = 16, FontWeight = FontWeights.Bold,
            FontFamily = (FontFamily)Application.Current.Resources["AppFont"],
        };
        Grid.SetRow(header, 0);
        root.Children.Add(header);

        var scroll = new ScrollViewer
        {
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
        };
        var body = new StackPanel { Margin = new Thickness(28, 20, 28, 0) };

        // Хелпер создания поля
        void Field(string label, ref TextBox field, bool multiline = false)
        {
            body.Children.Add(new TextBlock
            {
                Text       = label,
                Style      = (Style)Application.Current.Resources["LabelForm"],
                Margin     = new Thickness(0, 0, 0, 4),
            });
            field = new TextBox
            {
                Style         = (Style)Application.Current.Resources["AppTextBox"],
                Height        = multiline ? 60 : 36,
                Margin        = new Thickness(0, 0, 0, 14),
                AcceptsReturn = multiline,
                TextWrapping  = multiline ? TextWrapping.Wrap : TextWrapping.NoWrap,
            };
            body.Children.Add(field);
        }

        Field("Имя *",                ref _txtName);
        Field("Телефон *",            ref _txtPhone);
        Field("Email",                ref _txtEmail);
        Field("Адрес доставки *",     ref _txtAddr);
        Field("Комментарий к заказу", ref _txtComment, multiline: true);

        // Итого
        var totalPanel = new Border
        {
            Background   = new SolidColorBrush(Color.FromRgb(240, 244, 255)),
            CornerRadius = new CornerRadius(6),
            Padding      = new Thickness(14, 10, 14, 10),
            Margin       = new Thickness(0, 0, 0, 4),
        };
        totalPanel.Child = new TextBlock
        {
            Text       = $"Итого к оплате: {App.Cart.TotalFormatted}",
            FontFamily = (FontFamily)Application.Current.Resources["AppFont"],
            FontSize   = 14, FontWeight = FontWeights.Bold,
            Foreground = (Brush)Application.Current.Resources["PrimaryBrush"],
        };
        body.Children.Add(totalPanel);

        scroll.Content = body;
        Grid.SetRow(scroll, 1);
        root.Children.Add(scroll);

        // Кнопки
        var footer = new Border
        {
            Background      = Brushes.White,
            BorderBrush     = (Brush)Application.Current.Resources["BorderBrush"],
            BorderThickness = new Thickness(0, 1, 0, 0),
            Padding         = new Thickness(24, 12, 24, 16),
        };
        var btnRow = new StackPanel
        {
            Orientation         = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
        };

        var btnCancel = new Button
        {
            Content = "Отмена",
            Style   = (Style)Application.Current.Resources["BtnSecondary"],
            Margin  = new Thickness(0, 0, 10, 0),
        };
        btnCancel.Click += (_, _) => DialogResult = false;
        btnRow.Children.Add(btnCancel);

        var btnConfirm = new Button
        {
            Content = "Подтвердить заказ",
            Style   = (Style)Application.Current.Resources["BtnPrimary"],
        };
        btnConfirm.Click += BtnConfirm_Click;
        btnRow.Children.Add(btnConfirm);

        footer.Child = btnRow;
        Grid.SetRow(footer, 2);
        root.Children.Add(footer);

        Content = root;
    }

    private void BtnConfirm_Click(object sender, RoutedEventArgs e)
    {
        var errors = new System.Text.StringBuilder();
        if (string.IsNullOrWhiteSpace(_txtName.Text))  errors.AppendLine("• Введите имя.");
        if (string.IsNullOrWhiteSpace(_txtPhone.Text)) errors.AppendLine("• Введите телефон.");
        if (string.IsNullOrWhiteSpace(_txtAddr.Text))  errors.AppendLine("• Введите адрес.");

        if (errors.Length > 0)
        {
            MessageBox.Show(errors.ToString(), "Заполните обязательные поля",
                MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        var order = new Order
        {
            ClientName  = _txtName.Text.Trim(),
            ClientPhone = _txtPhone.Text.Trim(),
            ClientEmail = _txtEmail.Text.Trim(),
            Address     = _txtAddr.Text.Trim(),
            Comment     = _txtComment.Text.Trim(),
        };

        // Получаем userId из текущего пользователя (если залогинен)
        int? userId = App.Auth.CurrentUser?.Id;

        try
        {
            int newOrderId = App.Orders.Create(order, App.Cart.Items.ToList(), userId);

            MessageBox.Show(
                $"Заказ № {newOrderId} успешно оформлен!\n" +
                $"Итого: {App.Cart.TotalFormatted}\n\n" +
                $"Мы свяжемся с вами по телефону {order.ClientPhone}.",
                "Заказ оформлен",
                MessageBoxButton.OK, MessageBoxImage.Information);

            DialogResult = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                $"Ошибка при оформлении заказа:\n{ex.Message}",
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
