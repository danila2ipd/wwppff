using System.Windows;
using System.Windows.Controls;
using TechStore.Models;

namespace TechStore.Views.Admin.Pages;

public partial class ProductsAdminPage : Page
{
    public ProductsAdminPage()
    {
        InitializeComponent();
        LoadCategories();
        Loaded += (_, _) => Refresh();
    }

    private void LoadCategories()
    {
        var items = new List<object> { new { Id = (int?)null, Name = "Все категории" } };
        items.AddRange(App.Categories.GetAll().Cast<object>());
        CmbCategory.ItemsSource   = items;
        CmbCategory.SelectedIndex = 0;
    }

    private void Refresh()
    {
        var query   = TxtSearch.Text.Trim();
        int? catId  = (CmbCategory.SelectedItem as Category)?.Id;
        bool showAll = ChkShowAll.IsChecked == true;
        GridProducts.ItemsSource =
            App.Products.Search(query, catId, showAll);
    }

    private void Filter_Changed(object sender, RoutedEventArgs e) => Refresh();

    private void Grid_DoubleClick(object sender,
        System.Windows.Input.MouseButtonEventArgs e)
    {
        if (GridProducts.SelectedItem is Product p) OpenEdit(p.Id);
    }

    private void BtnAdd_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new ProductEditDialog(null) { Owner = Window.GetWindow(this) };
        if (dlg.ShowDialog() == true) Refresh();
    }

    private void BtnEdit_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { Tag: int id }) OpenEdit(id);
    }

    private void OpenEdit(int id)
    {
        var dlg = new ProductEditDialog(id) { Owner = Window.GetWindow(this) };
        if (dlg.ShowDialog() == true) Refresh();
    }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: int id }) return;
        var p = App.Products.GetById(id);
        if (p == null) return;
        var r = MessageBox.Show(
            $"Деактивировать товар «{p.Name}»?\n(записи в БД останутся)",
            "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
        if (r != MessageBoxResult.Yes) return;
        App.Products.SoftDelete(id);
        Refresh();
    }
}
