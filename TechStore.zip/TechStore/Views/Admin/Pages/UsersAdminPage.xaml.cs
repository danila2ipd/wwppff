using System.Windows;
using System.Windows.Controls;
using TechStore.Models;

namespace TechStore.Views.Admin.Pages;

public partial class UsersAdminPage : Page
{
    private User? _editing;

    public UsersAdminPage()
    {
        InitializeComponent();
        Loaded += (_, _) => Refresh();
    }

    private void Refresh() => GridUsers.ItemsSource = App.Auth.GetAll();

    private void Grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (GridUsers.SelectedItem is not User u) return;
        _editing = u;
        TxtFormTitle.Text       = "Редактировать";
        TxtLogin.Text           = u.Login;
        TxtFullName.Text        = u.FullName;
        TxtEmail.Text           = u.Email;
        ChkAdmin.IsChecked      = u.IsAdmin;
        ChkActive.IsChecked     = u.IsActive;
        TxtPassword.Clear();
        LblPasswordHint.Visibility = Visibility.Visible;
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        var login    = TxtLogin.Text.Trim();
        var password = TxtPassword.Password;

        if (string.IsNullOrEmpty(login))
        {
            MessageBox.Show("Введите логин.", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }
        if (_editing == null && string.IsNullOrEmpty(password))
        {
            MessageBox.Show("Введите пароль для нового пользователя.", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        try
        {
            if (_editing != null)
                App.Auth.Update(_editing.Id, login,
                    TxtFullName.Text.Trim(), TxtEmail.Text.Trim(),
                    ChkAdmin.IsChecked == true, ChkActive.IsChecked == true,
                    string.IsNullOrEmpty(password) ? null : password);
            else
                App.Auth.Create(login, password,
                    TxtFullName.Text.Trim(), TxtEmail.Text.Trim(),
                    ChkAdmin.IsChecked == true);

            BtnClear_Click(null, null!);
            Refresh();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: int id }) return;
        var r = MessageBox.Show("Удалить пользователя?",
            "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
        if (r != MessageBoxResult.Yes) return;
        try { App.Auth.Delete(id); Refresh(); }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnClear_Click(object? s, RoutedEventArgs e)
    {
        _editing = null; TxtFormTitle.Text = "Новый пользователь";
        TxtLogin.Text = ""; TxtFullName.Text = ""; TxtEmail.Text = "";
        TxtPassword.Clear(); ChkAdmin.IsChecked = false;
        ChkActive.IsChecked = true;
        LblPasswordHint.Visibility = Visibility.Collapsed;
        GridUsers.SelectedItem = null;
    }
}
