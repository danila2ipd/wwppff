using Microsoft.Win32;
using System.Windows;
using TechStore.Models;

namespace TechStore.Views.Admin.Pages;

public partial class ProductEditDialog : Window
{
    private readonly int? _productId;

    public ProductEditDialog(int? productId)
    {
        InitializeComponent();
        _productId = productId;

        CmbCategory.ItemsSource = App.Categories.GetAll();

        if (productId.HasValue)
        {
            TxtTitle.Text = "Редактировать товар";
            var p = App.Products.GetById(productId.Value);
            if (p != null)
            {
                TxtName.Text  = p.Name;
                TxtSku.Text   = p.Sku;
                TxtPrice.Text = p.Price.ToString("F2");
                TxtStock.Text = p.Stock.ToString();
                TxtDesc.Text  = p.Description;
                TxtImage.Text = p.ImagePath;
                ChkActive.IsChecked = p.IsActive;

                var cats = CmbCategory.ItemsSource as List<Category>;
                CmbCategory.SelectedItem = cats?.FirstOrDefault(c => c.Id == p.CategoryId);
            }
        }
    }

    private void BtnPickImage_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Filter = "Изображения|*.png;*.jpg;*.jpeg;*.webp|Все файлы|*.*",
            Title  = "Выбрать изображение",
        };
        if (dlg.ShowDialog() == true) TxtImage.Text = dlg.FileName;
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        var errors = new System.Text.StringBuilder();
        if (string.IsNullOrWhiteSpace(TxtName.Text))
            errors.AppendLine("• Название — обязательное поле.");
        if (CmbCategory.SelectedItem is not Category cat)
        {
            errors.AppendLine("• Выберите категорию.");
            if (errors.Length > 0) { Show(errors); return; }
            return;
        }
        if (!decimal.TryParse(TxtPrice.Text.Replace(',', '.'),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out decimal price) || price < 0)
            errors.AppendLine("• Цена: введите число ≥ 0.");
        if (!int.TryParse(TxtStock.Text, out int stock) || stock < 0)
            errors.AppendLine("• Остаток: целое число ≥ 0.");

        if (errors.Length > 0) { Show(errors); return; }

        try
        {
            if (_productId.HasValue)
                App.Products.Update(_productId.Value,
                    TxtName.Text.Trim(), TxtSku.Text.Trim(), cat.Id,
                    price, stock, TxtDesc.Text.Trim(),
                    TxtImage.Text.Trim(), ChkActive.IsChecked == true);
            else
                App.Products.Create(
                    TxtName.Text.Trim(), TxtSku.Text.Trim(), cat.Id,
                    price, stock, TxtDesc.Text.Trim(), TxtImage.Text.Trim());

            DialogResult = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка сохранения:\n{ex.Message}",
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void Show(System.Text.StringBuilder sb) =>
        MessageBox.Show(sb.ToString(), "Ошибки заполнения",
            MessageBoxButton.OK, MessageBoxImage.Error);

    private void BtnCancel_Click(object sender, RoutedEventArgs e) =>
        DialogResult = false;
}
