using System.Windows;
using System.Windows.Controls;
using TechStore.Views.Admin;

namespace TechStore.Views.Admin.Pages;

public partial class DashboardPage : Page
{
    public DashboardPage()
    {
        InitializeComponent();
        Loaded += (_, _) => LoadData();
    }

    private void LoadData()
    {
        TxtDate.Text = $"Сегодня: {DateTime.Now:dddd, d MMMM yyyy}";

        var s = App.Products.GetStats();
        TxtRevenue.Text    = s.RevenueFormatted;
        TxtOrders.Text     = s.TotalOrders.ToString();
        TxtNewOrders.Text  = s.NewOrders > 0 ? $"{s.NewOrders} новых ожидают" : "нет новых";
        TxtProducts.Text   = s.ActiveProducts.ToString();
        TxtOutOfStock.Text = s.OutOfStockProducts > 0
            ? $"{s.OutOfStockProducts} нет в наличии" : "всё в наличии";
        TxtCategories.Text = s.ActiveCategories.ToString();

        GridRecentOrders.ItemsSource = App.Orders.GetAll().Take(10).ToList();
    }

    private void BtnAllOrders_Click(object sender, RoutedEventArgs e)
    {
        if (Window.GetWindow(this) is AdminWindow aw)
            aw.Navigate("Orders");
    }
}
