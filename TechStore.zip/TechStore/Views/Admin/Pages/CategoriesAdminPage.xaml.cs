using System.Windows;
using System.Windows.Controls;
using TechStore.Models;

namespace TechStore.Views.Admin.Pages;

public partial class CategoriesAdminPage : Page
{
    private Category? _editing;

    public CategoriesAdminPage()
    {
        InitializeComponent();
        Loaded += (_, _) => Refresh();
    }

    private void Refresh() =>
        GridCats.ItemsSource = App.Categories.GetAll(includeInactive: true);

    private void Grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (GridCats.SelectedItem is not Category c) return;
        _editing = c;
        TxtFormTitle.Text   = "Редактировать";
        TxtName.Text        = c.Name;
        TxtDesc.Text        = c.Description;
        TxtSort.Text        = c.SortOrder.ToString();
        ChkActive.IsChecked = c.IsActive;
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(TxtName.Text))
        {
            MessageBox.Show("Введите название.", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }
        if (!int.TryParse(TxtSort.Text, out int sort)) sort = 0;
        try
        {
            if (_editing != null)
                App.Categories.Update(_editing.Id, TxtName.Text.Trim(),
                    TxtDesc.Text.Trim(), sort, ChkActive.IsChecked == true);
            else
                App.Categories.Create(TxtName.Text.Trim(), TxtDesc.Text.Trim(), sort);
            BtnClear_Click(null, null!);
            Refresh();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: int id }) return;
        var r = MessageBox.Show("Удалить категорию?",
            "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
        if (r != MessageBoxResult.Yes) return;
        try { App.Categories.Delete(id); Refresh(); }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnClear_Click(object? s, RoutedEventArgs e)
    {
        _editing = null; TxtFormTitle.Text = "Новая категория";
        TxtName.Text = ""; TxtDesc.Text = ""; TxtSort.Text = "0";
        ChkActive.IsChecked = true; GridCats.SelectedItem = null;
    }
}
