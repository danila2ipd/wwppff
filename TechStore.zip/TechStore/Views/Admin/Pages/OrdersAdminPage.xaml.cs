using System.Windows;
using System.Windows.Controls;
using TechStore.Models;

namespace TechStore.Views.Admin.Pages;

public partial class OrdersAdminPage : Page
{
    private static readonly (int? Value, string Label)[] _statuses =
    {
        (null, "Все статусы"),
        (0, "Новый"),
        (1, "В обработке"),
        (2, "Отправлен"),
        (3, "Доставлен"),
        (4, "Отменён"),
    };

    public OrdersAdminPage()
    {
        InitializeComponent();
        CmbStatus.ItemsSource       = _statuses.Select(s => s.Label).ToList();
        CmbStatus.SelectedIndex     = 0;
        Loaded += (_, _) => Refresh();
    }

    private void Refresh()
    {
        int? filter = _statuses[CmbStatus.SelectedIndex].Value;
        var orders  = App.Orders.GetAll(filter);
        GridOrders.ItemsSource = orders;
        TxtCount.Text = $"Показано: {orders.Count} заказов";
    }

    private void CmbStatus_Changed(object sender, SelectionChangedEventArgs e) => Refresh();

    private void Grid_DoubleClick(object sender,
        System.Windows.Input.MouseButtonEventArgs e)
    {
        if (GridOrders.SelectedItem is Order o) OpenDetail(o.Id);
    }

    private void BtnOpen_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { Tag: int id }) OpenDetail(id);
    }

    private void OpenDetail(int id)
    {
        var dlg = new OrderDetailDialog(id) { Owner = Window.GetWindow(this) };
        dlg.ShowDialog();
        Refresh();
    }
}

// ──────────────────────────────────────────────────────────
public class OrderDetailDialog : Window
{
    public OrderDetailDialog(int orderId)
    {
        Width  = 580; Height = 580;
        Title  = $"Заказ № {orderId}";
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Background = (System.Windows.Media.Brush)
            Application.Current.Resources["BgBrush"];

        var order = App.Orders.GetById(orderId);
        var items = App.Orders.GetItems(orderId);
        if (order == null) { Close(); return; }
        BuildUI(order, items);
    }

    private void BuildUI(Order order, List<OrderItem> items)
    {
        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        // Шапка
        var hdr = new Border
        {
            Background = (System.Windows.Media.Brush)Application.Current.Resources["PrimaryBrush"],
            Padding    = new Thickness(24, 14, 24, 14),
        };
        hdr.Child = new TextBlock
        {
            Text = $"Заказ № {order.Id}   •   {order.TotalFormatted}   •   {order.StatusLabel}",
            Foreground = System.Windows.Media.Brushes.White,
            FontSize = 15, FontWeight = FontWeights.Bold,
            FontFamily = (System.Windows.Media.FontFamily)Application.Current.Resources["AppFont"],
        };
        Grid.SetRow(hdr, 0); root.Children.Add(hdr);

        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var body   = new StackPanel { Margin = new Thickness(24, 16, 24, 0) };

        void Row(string lbl, string val)
        {
            var sp = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
            sp.Children.Add(new TextBlock
            {
                Text = lbl, FontWeight = FontWeights.SemiBold, FontSize = 11,
                Foreground = (System.Windows.Media.Brush)Application.Current.Resources["TextSecBrush"],
                FontFamily = (System.Windows.Media.FontFamily)Application.Current.Resources["AppFont"],
            });
            sp.Children.Add(new TextBlock
            {
                Text = val, FontSize = 13, TextWrapping = TextWrapping.Wrap,
                FontFamily = (System.Windows.Media.FontFamily)Application.Current.Resources["AppFont"],
            });
            body.Children.Add(sp);
        }

        Row("Клиент",  order.ClientName);
        Row("Телефон", order.ClientPhone);
        Row("Email",   order.ClientEmail);
        Row("Адрес",   order.Address);
        Row("Дата",    order.CreatedAt.ToString("dd.MM.yyyy HH:mm"));
        if (!string.IsNullOrEmpty(order.Comment)) Row("Комментарий", order.Comment);

        body.Children.Add(new TextBlock
        {
            Text = "Состав заказа", FontSize = 14, FontWeight = FontWeights.SemiBold,
            Margin = new Thickness(0, 8, 0, 8),
            FontFamily = (System.Windows.Media.FontFamily)Application.Current.Resources["AppFont"],
        });

        var dg = new DataGrid
        {
            Style = (Style)Application.Current.Resources["AppDataGrid"],
            MaxHeight = 160, ItemsSource = items,
        };
        dg.Columns.Add(new DataGridTextColumn
        {
            Header = "Товар", Width = new DataGridLength(1, DataGridLengthUnitType.Star),
            Binding = new System.Windows.Data.Binding("ProductName"),
        });
        dg.Columns.Add(new DataGridTextColumn
        {
            Header = "Кол-во", Width = new DataGridLength(70),
            Binding = new System.Windows.Data.Binding("Quantity"),
        });
        dg.Columns.Add(new DataGridTextColumn
        {
            Header = "Цена", Width = new DataGridLength(120),
            Binding = new System.Windows.Data.Binding("UnitPriceFormatted"),
        });
        dg.Columns.Add(new DataGridTextColumn
        {
            Header = "Сумма", Width = new DataGridLength(120),
            Binding = new System.Windows.Data.Binding("SubtotalFormatted"),
        });
        body.Children.Add(dg);

        // Смена статуса
        body.Children.Add(new TextBlock
        {
            Text = "Изменить статус", FontSize = 13, FontWeight = FontWeights.SemiBold,
            Margin = new Thickness(0, 16, 0, 8),
            FontFamily = (System.Windows.Media.FontFamily)Application.Current.Resources["AppFont"],
        });
        var btnRow = new WrapPanel();
        foreach (var (val, lbl) in new[]
        {
            (0,"Новый"),(1,"В обработке"),(2,"Отправлен"),(3,"Доставлен"),(4,"Отменён")
        })
        {
            int v = val; string l = lbl;
            var btn = new Button
            {
                Content = l, Margin = new Thickness(0, 0, 8, 6),
                Style   = order.Status == v
                    ? (Style)Application.Current.Resources["BtnPrimary"]
                    : (Style)Application.Current.Resources["BtnSecondary"],
            };
            btn.Click += (_, _) =>
            {
                App.Orders.UpdateStatus(order.Id, v);
                Close();
            };
            btnRow.Children.Add(btn);
        }
        body.Children.Add(btnRow);

        scroll.Content = body;
        Grid.SetRow(scroll, 1); root.Children.Add(scroll);

        var footer = new Border
        {
            Padding = new Thickness(24, 10, 24, 14), Background = System.Windows.Media.Brushes.White,
            BorderBrush = (System.Windows.Media.Brush)Application.Current.Resources["BorderBrush"],
            BorderThickness = new Thickness(0, 1, 0, 0),
        };
        var close = new Button
        {
            Content = "Закрыть",
            Style   = (Style)Application.Current.Resources["BtnSecondary"],
            Width   = 100, HorizontalAlignment = HorizontalAlignment.Right,
        };
        close.Click += (_, _) => Close();
        footer.Child = close;
        Grid.SetRow(footer, 2); root.Children.Add(footer);

        Content = root;
    }
}
