using System.Windows;
using System.Windows.Controls;
using TechStore.Views.Admin.Pages;

namespace TechStore.Views.Admin;

public partial class AdminWindow : Window
{
    private Button? _activeNavBtn;

    public AdminWindow()
    {
        InitializeComponent();
        TxtAdminName.Text = $"👤 {App.Auth.CurrentUser?.FullName ?? App.Auth.CurrentUser?.Login}";
        Navigate("Dashboard");
    }

    private void NavButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button btn)
            Navigate(btn.Tag?.ToString() ?? "Dashboard");
    }

    internal void Navigate(string page)
    {
        // Подсветка активной кнопки
        if (_activeNavBtn != null)
            _activeNavBtn.Background = System.Windows.Media.Brushes.Transparent;

        _activeNavBtn = page switch
        {
            "Dashboard"  => BtnNavDashboard,
            "Products"   => BtnNavProducts,
            "Categories" => BtnNavCategories,
            "Orders"     => BtnNavOrders,
            "Users"      => BtnNavUsers,
            _            => BtnNavDashboard,
        };
        _activeNavBtn.Background = (System.Windows.Media.Brush)
            FindResource("SidebarItemActive");

        // Навигация фрейма
        ContentFrame.Navigate(page switch
        {
            "Dashboard"  => (object)new DashboardPage(),
            "Products"   => new ProductsAdminPage(),
            "Categories" => new CategoriesAdminPage(),
            "Orders"     => new OrdersAdminPage(),
            "Users"      => new UsersAdminPage(),
            _            => new DashboardPage(),
        });
    }

    private void BtnLogout_Click(object sender, RoutedEventArgs e)
    {
        var r = MessageBox.Show("Выйти из панели администратора?",
                                "Подтверждение",
                                MessageBoxButton.YesNo,
                                MessageBoxImage.Question);
        if (r != MessageBoxResult.Yes) return;
        App.Auth.Logout();
        Close();
    }

    private void BtnBackToShop_Click(object sender, RoutedEventArgs e)
    {
        var shop = new MainShopWindow();
        shop.Show();
        Close();
    }
}
