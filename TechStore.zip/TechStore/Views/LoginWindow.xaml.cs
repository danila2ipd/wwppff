using System.Windows;
using System.Windows.Input;
using TechStore.Views.Admin;

namespace TechStore.Views;

public partial class LoginWindow : Window
{
    public LoginWindow()
    {
        InitializeComponent();
        TxtStoreName.Text = StoreConfig.StoreName;
        TxtLogin.Focus();
    }

    private void BtnLogin_Click(object sender, RoutedEventArgs e) => TryLogin();
    private void Input_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) TryLogin();
    }

    private void TryLogin()
    {
        PanelError.Visibility = Visibility.Collapsed;
        var login    = TxtLogin.Text.Trim();
        var password = TxtPassword.Password;

        if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
        {
            ShowError("Введите логин и пароль.");
            return;
        }

        bool ok = App.Auth.Login(login, password);
        if (!ok)
        {
            ShowError("Неверный логин или пароль.");
            TxtPassword.Clear();
            TxtPassword.Focus();
            return;
        }

        if (!App.Auth.IsAdmin)
        {
            App.Auth.Logout();
            ShowError("Доступ запрещён: у вас нет прав администратора.");
            return;
        }

        // Успешный вход — открываем панель
        var adminPanel = new AdminWindow();
        adminPanel.Show();
        Close();
    }

    private void ShowError(string msg)
    {
        TxtError.Text            = msg;
        PanelError.Visibility    = Visibility.Visible;
    }

    private void BtnClose_Click(object sender, RoutedEventArgs e) => Close();
}
