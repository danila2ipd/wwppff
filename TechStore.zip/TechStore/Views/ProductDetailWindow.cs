using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using TechStore.Models;

namespace TechStore.Views;

/// <summary>Окно подробного просмотра товара (генерируется кодом).</summary>
public class ProductDetailWindow : Window
{
    public ProductDetailWindow(Product product)
    {
        Title  = product.Name;
        Width  = 540; Height = 480;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Background = (Brush)Application.Current.Resources["BgBrush"];

        var grid = new Grid();
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        // Шапка
        var header = new Border
        {
            Background = (Brush)Application.Current.Resources["PrimaryBrush"],
            Padding    = new Thickness(24, 14, 24, 14),
        };
        header.Child = new TextBlock
        {
            Text       = product.Name,
            Foreground = Brushes.White,
            FontSize   = 15, FontWeight = FontWeights.Bold,
            FontFamily = (FontFamily)Application.Current.Resources["AppFont"],
            TextWrapping = TextWrapping.Wrap,
        };
        Grid.SetRow(header, 0);
        grid.Children.Add(header);

        // Тело
        var bodyScroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var body       = new Grid { Margin = new Thickness(24, 16, 24, 0) };
        body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(170) });
        body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        // Изображение
        var imgBorder = new Border
        {
            Width = 160, Height = 160,
            Background   = new SolidColorBrush(Color.FromRgb(240, 244, 250)),
            CornerRadius = new CornerRadius(8),
            Margin       = new Thickness(0, 0, 16, 0),
        };
        if (!string.IsNullOrEmpty(product.ImagePath) &&
            System.IO.File.Exists(product.ImagePath))
        {
            try
            {
                imgBorder.Child = new Image
                {
                    Source  = new BitmapImage(new Uri(product.ImagePath)),
                    Stretch = Stretch.UniformToFill,
                };
            }
            catch { }
        }
        Grid.SetColumn(imgBorder, 0);
        body.Children.Add(imgBorder);

        // Инфо
        var info = new StackPanel();
        Grid.SetColumn(info, 1);

        void Row(string label, string val, Brush? color = null)
        {
            info.Children.Add(new TextBlock
            {
                Text       = label,
                FontFamily = (FontFamily)Application.Current.Resources["AppFont"],
                FontSize   = 11, FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)Application.Current.Resources["TextSecBrush"],
                Margin     = new Thickness(0, 0, 0, 2),
            });
            info.Children.Add(new TextBlock
            {
                Text         = val,
                FontFamily   = (FontFamily)Application.Current.Resources["AppFont"],
                FontSize     = 13,
                Foreground   = color ?? (Brush)Application.Current.Resources["TextPrimaryBrush"],
                Margin       = new Thickness(0, 0, 0, 10),
                TextWrapping = TextWrapping.Wrap,
            });
        }

        Row("Артикул",   product.Sku);
        Row("Категория", product.CategoryName);
        Row("Цена",      product.PriceFormatted,
            (Brush)Application.Current.Resources["PrimaryBrush"]);
        Row("Наличие",   product.StockStatus,
            product.Stock == 0
                ? (Brush)Application.Current.Resources["DangerBrush"]
                : (Brush)Application.Current.Resources["SuccessBrush"]);
        if (!string.IsNullOrEmpty(product.Description))
            Row("Описание", product.Description);

        body.Children.Add(info);
        bodyScroll.Content = body;
        Grid.SetRow(bodyScroll, 1);
        grid.Children.Add(bodyScroll);

        // Кнопки
        var footer = new Border
        {
            Padding = new Thickness(24, 12, 24, 16),
            Background = Brushes.White,
            BorderBrush = (Brush)Application.Current.Resources["BorderBrush"],
            BorderThickness = new Thickness(0, 1, 0, 0),
        };
        var btnPanel = new StackPanel { Orientation = Orientation.Horizontal,
                                        HorizontalAlignment = HorizontalAlignment.Right };

        if (product.InStock)
        {
            var btnCart = new Button
            {
                Content = "Добавить в корзину",
                Style   = (Style)Application.Current.Resources["BtnPrimary"],
                Margin  = new Thickness(0, 0, 8, 0),
            };
            btnCart.Click += (_, _) =>
            {
                App.Cart.Add(product);
                MessageBox.Show($"«{product.Name}» добавлен в корзину.",
                                "Корзина", MessageBoxButton.OK,
                                MessageBoxImage.Information);
                Close();
            };
            btnPanel.Children.Add(btnCart);
        }

        var btnClose = new Button
        {
            Content = "Закрыть",
            Style   = (Style)Application.Current.Resources["BtnSecondary"],
        };
        btnClose.Click += (_, _) => Close();
        btnPanel.Children.Add(btnClose);

        footer.Child = btnPanel;
        Grid.SetRow(footer, 2);
        grid.Children.Add(footer);

        Content = grid;
    }
}
