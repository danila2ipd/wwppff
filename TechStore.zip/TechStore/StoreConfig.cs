namespace TechStore;

/// <summary>
/// ╔══════════════════════════════════════════════════════════╗
/// ║      ГЛАВНЫЙ ФАЙЛ НАСТРОЙКИ МАГАЗИНА                    ║
/// ║  Чтобы сменить тип магазина — меняйте только этот файл  ║
/// ╚══════════════════════════════════════════════════════════╝
/// </summary>
public static class StoreConfig
{
    // ── Название и описание ─────────────────────────────────
    public const string StoreName = "TechStore";
    public const string StoreSubtitle = "Магазин электроники и техники";
    public const string CurrencySymbol = "₽";

    // ── Цвета (HEX) ─────────────────────────────────────────
    public const string ColorPrimary = "#1565C0";
    public const string ColorPrimaryDark = "#0D47A1";
    public const string ColorAccent = "#FF6F00";

    // ── Терминология ────────────────────────────────────────
    public const string TermProduct = "Товар";
    public const string TermProducts = "Товары";
    public const string TermCategory = "Категория";
    public const string TermOrder = "Заказ";
    public const string TermOrders = "Заказы";
    public const string TermCart = "Корзина";
    public const string TermSku = "Артикул";

    // ── Логика ──────────────────────────────────────────────
    public const int LowStockThreshold = 5;

    // ── Строка подключения к SQL Server ─────────────────────
    // Измените Server= на имя вашего экземпляра SQL Server
    // Если используете SQL-аутентификацию — замените Integrated Security на
    //   User Id=sa;Password=yourpassword;
    public static string ConnectionString =>
        "Server=DESKTOP-P6FSIOR\\SQLEXPRESS;" +
        "Database=TechStoreDB;" +
        "Integrated Security=True;" +
        "TrustServerCertificate=True;";
}

/* ════════════════════════════════════════════════════════════
 * ГОТОВЫЕ КОНФИГУРАЦИИ — раскомментируй нужную
 * ════════════════════════════════════════════════════════════

// ── Книжный магазин ───────────────────────────────
// StoreName      = "BookShop"
// ColorPrimary   = "#4A235A"
// ColorAccent    = "#D4AC0D"
// TermProduct    = "Книга"
// TermSku        = "ISBN"

// ── Магазин одежды ────────────────────────────────
// StoreName      = "FashionStore"
// ColorPrimary   = "#880E4F"
// TermProduct    = "Товар"

// ── Ресторан ──────────────────────────────────────
// StoreName      = "FoodDelivery"
// ColorPrimary   = "#BF360C"
// TermProduct    = "Блюдо"
// TermProducts   = "Меню"

*/
