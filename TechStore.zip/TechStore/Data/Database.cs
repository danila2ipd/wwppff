using Microsoft.Data.SqlClient;
using TechStore.Models;

namespace TechStore.Data;

/// <summary>
/// Единая точка работы с SQL Server через ADO.NET.
/// Все запросы — через хранимые процедуры и представления из TechStoreDB.sql.
/// </summary>
public static class Database
{
    // ── Открыть соединение ───────────────────────────────────
    public static SqlConnection Open()
    {
        var conn = new SqlConnection(StoreConfig.ConnectionString);
        conn.Open();
        return conn;
    }

    // ── Вспомогательные методы ───────────────────────────────

    /// <summary>ExecuteNonQuery с параметрами.</summary>
    public static int Exec(string sql, Action<SqlCommand>? setup = null,
                           bool isProc = true)
    {
        using var conn = Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.CommandType = isProc
            ? System.Data.CommandType.StoredProcedure
            : System.Data.CommandType.Text;
        setup?.Invoke(cmd);
        return cmd.ExecuteNonQuery();
    }

    /// <summary>ExecuteScalar — вернуть одно значение.</summary>
    public static T? Scalar<T>(string sql, Action<SqlCommand>? setup = null,
                                bool isProc = false)
    {
        using var conn = Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.CommandType = isProc
            ? System.Data.CommandType.StoredProcedure
            : System.Data.CommandType.Text;
        setup?.Invoke(cmd);
        var result = cmd.ExecuteScalar();
        if (result == null || result == DBNull.Value) return default;
        return (T)Convert.ChangeType(result, typeof(T));
    }

    /// <summary>Читает строки и маппит через factory.</summary>
    public static List<T> Query<T>(string sql, Func<SqlDataReader, T> map,
                                   Action<SqlCommand>? setup = null,
                                   bool isProc = false)
    {
        using var conn = Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.CommandType = isProc
            ? System.Data.CommandType.StoredProcedure
            : System.Data.CommandType.Text;
        setup?.Invoke(cmd);
        using var rdr = cmd.ExecuteReader();
        var list = new List<T>();
        while (rdr.Read()) list.Add(map(rdr));
        return list;
    }

    // ── Расширения SqlDataReader ─────────────────────────────
    public static string Str(this SqlDataReader r, string col) =>
        r.IsDBNull(r.GetOrdinal(col)) ? "" : r.GetString(r.GetOrdinal(col));

    // Convert.ToInt32 обрабатывает TINYINT (byte), SMALLINT (short), INT, BIGINT
    public static int Int(this SqlDataReader r, string col) =>
        r.IsDBNull(r.GetOrdinal(col)) ? 0
            : Convert.ToInt32(r.GetValue(r.GetOrdinal(col)));

    public static bool Bool(this SqlDataReader r, string col) =>
        !r.IsDBNull(r.GetOrdinal(col)) && Convert.ToBoolean(r.GetValue(r.GetOrdinal(col)));

    public static decimal Dec(this SqlDataReader r, string col) =>
        r.IsDBNull(r.GetOrdinal(col)) ? 0m
            : Convert.ToDecimal(r.GetValue(r.GetOrdinal(col)));

    public static DateTime DT(this SqlDataReader r, string col) =>
        r.IsDBNull(r.GetOrdinal(col)) ? DateTime.MinValue
            : r.GetDateTime(r.GetOrdinal(col));

    public static int? NullInt(this SqlDataReader r, string col) =>
        r.IsDBNull(r.GetOrdinal(col)) ? null
            : Convert.ToInt32(r.GetValue(r.GetOrdinal(col)));

    /// <summary>Проверяет соединение с БД. Возвращает null если OK, иначе текст ошибки.</summary>
    public static string? TestConnection()
    {
        try
        {
            using var conn = Open();
            return null;
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
    }
}
