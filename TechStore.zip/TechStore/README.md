# TechStore — WPF-приложение магазина

> **Готовый шаблон магазина на C# WPF + SQLite (EF Core)**  
> Легко адаптируется под любой тип товаров — книги, одежда, еда и т.д.

---

## Быстрый старт

1. Открыть `TechStore.csproj` в **Visual Studio 2022**
2. `dotnet restore` (автоматически при открытии)
3. **F5** — при первом запуске создаётся `store.db` и загружаются демо-данные

**Логин по умолчанию:**  `admin` / `admin123`

---

## Структура проекта

```
TechStore/
├── StoreConfig.cs               ← ВСЕ НАСТРОЙКИ МАГАЗИНА ЗДЕСЬ
│
├── Models/Models.cs             — User, Category, Product, Order, OrderItem, CartItem
├── Data/AppDbContext.cs         — EF Core + SQLite + Seed
├── Services/Services.cs        — AuthService, CategoryService, ProductService,
│                                  OrderService, CartService
├── Helpers/Converters.cs       — Конвертеры для биндингов
│
├── Views/
│   ├── LoginWindow              — Вход для администратора
│   ├── MainShopWindow           — Витрина магазина
│   ├── CartWindow               — Корзина
│   ├── CheckoutWindow           — Оформление заказа
│   ├── ProductDetailWindow      — Карточка товара
│   └── Admin/
│       ├── AdminWindow          — Обёртка с боковым меню
│       └── Pages/
│           ├── DashboardPage    — Дашборд: статистика, последние заказы
│           ├── ProductsAdminPage  — Список товаров + поиск/фильтр
│           ├── ProductEditDialog  — Добавление/редактирование товара
│           ├── CategoriesAdminPage — Управление категориями
│           ├── OrdersAdminPage    — Заказы + смена статуса
│           └── UsersAdminPage     — Управление пользователями
│
├── Styles/
│   ├── Colors.xaml              — Цвета и кисти
│   └── Controls.xaml            — Стили кнопок, полей, таблиц
│
└── App.xaml / App.xaml.cs       — Точка входа + DI-контейнер
```

---

## Как изменить тип магазина

Откройте **`StoreConfig.cs`** — там сосредоточены **все** настройки:

```csharp
// Название и описание
public const string StoreName     = "TechStore";
public const string StoreSubtitle = "Магазин электроники";

// Цвета (измените на нужные)
public const string ColorPrimary  = "#1565C0";   // синий → замените на нужный
public const string ColorAccent   = "#FF6F00";

// Терминология (товар → блюдо, категория → раздел меню и т.д.)
public const string TermProduct   = "Товар";
public const string TermCategory  = "Категория";

// Начальные категории
public static readonly string[] DefaultCategories = { "Смартфоны", "Ноутбуки", ... };
```

**Примеры** готовых конфигураций (книжный магазин, одежда, ресторан)
закомментированы в конце файла `StoreConfig.cs`.

> ⚠️ После смены категорий удалите `store.db` — при следующем запуске
> база создастся заново с новыми категориями.

---

## База данных

Используется **SQLite** через **Entity Framework Core 8**.  
Файл `store.db` создаётся рядом с `.exe` при первом запуске.

### Схема

| Таблица       | Описание                              |
|---------------|---------------------------------------|
| `Users`       | Администраторы / менеджеры            |
| `Categories`  | Категории товаров                     |
| `Products`    | Товары (цена, остаток, описание)      |
| `Orders`      | Заказы клиентов                       |
| `OrderItems`  | Позиции заказов (фиксированная цена)  |

### Смена СУБД

Замените `Npgsql` / `SQLite` NuGet-пакет и строку в `AppDbContext.OnConfiguring`:

```csharp
// PostgreSQL:
opt.UseNpgsql("Host=...;Database=...;Username=...;Password=...");

// SQL Server:
opt.UseSqlServer("Server=...;Database=...;Trusted_Connection=True;");
```

---

## Функции

### Магазин (витрина)
- Каталог товаров с карточками
- Фильтр по категориям + поиск
- Статус наличия (в наличии / мало / нет)
- Детальный просмотр товара
- Корзина с изменением количества
- Оформление заказа с данными клиента

### Админ-панель
- **Дашборд** — выручка, количество заказов, товаров, категорий
- **Товары** — добавление, редактирование, мягкое удаление, фильтрация
- **Категории** — CRUD, сортировка, активация
- **Заказы** — просмотр, смена статуса (Новый → В обработке → Отправлен → Доставлен)
- **Пользователи** — создание, редактирование, удаление, роли

---

## NuGet пакеты

| Пакет                                   | Версия |
|-----------------------------------------|--------|
| `Microsoft.EntityFrameworkCore`         | 8.0.3  |
| `Microsoft.EntityFrameworkCore.Sqlite`  | 8.0.3  |
| `Microsoft.EntityFrameworkCore.Tools`   | 8.0.3  |
| `BCrypt.Net-Next`                       | 4.0.3  |
