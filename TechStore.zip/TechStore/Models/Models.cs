namespace TechStore.Models;

public class User
{
    public int      Id           { get; set; }
    public string   Login        { get; set; } = "";
    public string   PasswordHash { get; set; } = "";
    public string   FullName     { get; set; } = "";
    public string   Email        { get; set; } = "";
    public int      RoleId       { get; set; }
    public bool     IsAdmin      => RoleId == 1;
    public bool     IsActive     { get; set; }
    public DateTime CreatedAt    { get; set; }
}

public class Category
{
    public int    Id          { get; set; }
    public string Name        { get; set; } = "";
    public string Description { get; set; } = "";
    public int    SortOrder   { get; set; }
    public bool   IsActive    { get; set; }

    public override string ToString() => Name;
}

public class Product
{
    public int      Id           { get; set; }
    public int      CategoryId   { get; set; }
    public string   CategoryName { get; set; } = "";
    public string   Name         { get; set; } = "";
    public string   Description  { get; set; } = "";
    public string   Sku          { get; set; } = "";
    public decimal  Price        { get; set; }
    public int      Stock        { get; set; }
    public string   ImagePath    { get; set; } = "";
    public bool     IsActive     { get; set; }
    public DateTime CreatedAt    { get; set; }
    public string   StockStatus  { get; set; } = "";

    public string  PriceFormatted => $"{Price:N2} {StoreConfig.CurrencySymbol}";
    public bool    InStock        => Stock > 0;
    public bool    LowStock       => Stock > 0 && Stock <= StoreConfig.LowStockThreshold;
}

public class Order
{
    public int       Id          { get; set; }
    public int?      UserId      { get; set; }
    public string    ClientName  { get; set; } = "";
    public string    ClientPhone { get; set; } = "";
    public string    ClientEmail { get; set; } = "";
    public string    Address     { get; set; } = "";
    public string    Comment     { get; set; } = "";
    public int       Status      { get; set; }
    public string    StatusLabel { get; set; } = "";
    public DateTime  CreatedAt   { get; set; }
    public DateTime? UpdatedAt   { get; set; }
    public decimal   Total       { get; set; }
    public int       ItemCount   { get; set; }

    public string TotalFormatted => $"{Total:N2} {StoreConfig.CurrencySymbol}";
}

public class OrderItem
{
    public int     Id        { get; set; }
    public int     OrderId   { get; set; }
    public int     ProductId { get; set; }
    public string  ProductName { get; set; } = "";
    public int     Quantity  { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal Subtotal  => Quantity * UnitPrice;

    public string UnitPriceFormatted  => $"{UnitPrice:N2} {StoreConfig.CurrencySymbol}";
    public string SubtotalFormatted   => $"{Subtotal:N2} {StoreConfig.CurrencySymbol}";
}

public class CartItem
{
    public Product Product  { get; set; } = null!;
    public int     Quantity { get; set; }
    public decimal Subtotal => Product.Price * Quantity;
    public string  SubtotalFormatted => $"{Subtotal:N2} {StoreConfig.CurrencySymbol}";
}

public class DashboardStats
{
    public int     TotalOrders        { get; set; }
    public int     NewOrders          { get; set; }
    public decimal TotalRevenue       { get; set; }
    public int     ActiveProducts     { get; set; }
    public int     OutOfStockProducts { get; set; }
    public int     ActiveCategories   { get; set; }
    public int     ActiveUsers        { get; set; }

    public string RevenueFormatted =>
        $"{TotalRevenue:N2} {StoreConfig.CurrencySymbol}";
}
