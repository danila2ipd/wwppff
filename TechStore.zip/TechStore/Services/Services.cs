using Microsoft.Data.SqlClient;
using System.Xml.Linq;
using System.Windows;
using TechStore.Data;
using TechStore.Models;

namespace TechStore.Services;

// ═══════════════════════════════════════════════════════════
// AuthService
// ═══════════════════════════════════════════════════════════
public class AuthService
{
    public User? CurrentUser { get; private set; }
    public bool IsLoggedIn => CurrentUser != null;
    public bool IsAdmin => CurrentUser?.IsAdmin == true;

    public bool Login(string login, string password)
    {
        // Читаем пользователя из БД
        User? user = null;
        try
        {
            using var conn = Database.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM Users WHERE Login=@l AND IsActive=1";
            cmd.Parameters.AddWithValue("@l", login.Trim());

            using var rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                user = new User
                {
                    Id = Convert.ToInt32(rdr.GetValue(rdr.GetOrdinal("Id"))),
                    Login = rdr.GetString(rdr.GetOrdinal("Login")),
                    PasswordHash = rdr.GetString(rdr.GetOrdinal("PasswordHash")).Trim(),
                    FullName = rdr.IsDBNull(rdr.GetOrdinal("FullName")) ? ""
                                   : rdr.GetString(rdr.GetOrdinal("FullName")),
                    Email = rdr.IsDBNull(rdr.GetOrdinal("Email")) ? ""
                                   : rdr.GetString(rdr.GetOrdinal("Email")),
                    RoleId = Convert.ToInt32(rdr.GetValue(rdr.GetOrdinal("RoleId"))),
                    IsActive = Convert.ToBoolean(rdr.GetValue(rdr.GetOrdinal("IsActive"))),
                };
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка чтения пользователя:\n{ex.Message}",
                "Ошибка БД", MessageBoxButton.OK, MessageBoxImage.Error);
            return false;
        }

        if (user == null) return false;

        // Проверяем хэш
        try
        {
            bool ok = BCrypt.Net.BCrypt.Verify(password.Trim(), user.PasswordHash);
            if (!ok) return false;
        }
        catch (Exception ex)
        {
            // Хэш повреждён — показываем что именно
            MessageBox.Show(
                $"Ошибка проверки пароля: {ex.Message}\n\n" +
                $"Длина хэша в БД: {user.PasswordHash.Length}\n" +
                $"Первые 10 символов: {user.PasswordHash[..Math.Min(10, user.PasswordHash.Length)]}\n\n" +
                "Запустите приложение заново — пароль сбросится автоматически.",
                "Ошибка BCrypt", MessageBoxButton.OK, MessageBoxImage.Error);
            return false;
        }

        CurrentUser = user;
        return true;
    }

    public void Logout() => CurrentUser = null;

    public List<User> GetAll() =>
        Database.Query(
            "SELECT u.*, r.Name AS RoleName FROM Users u JOIN Roles r ON r.Id=u.RoleId ORDER BY u.Login",
            r => new User
            {
                Id = r.Int("Id"),
                Login = r.Str("Login"),
                FullName = r.Str("FullName"),
                Email = r.Str("Email"),
                RoleId = r.Int("RoleId"),
                IsActive = r.Bool("IsActive"),
                CreatedAt = r.DT("CreatedAt"),
            });

    public void Create(string login, string password, string fullName,
                       string email, bool isAdmin)
    {
        bool exists = Database.Scalar<int>(
            "SELECT COUNT(*) FROM Users WHERE Login=@l",
            cmd => cmd.Parameters.AddWithValue("@l", login)) > 0;
        if (exists)
            throw new InvalidOperationException($"Логин «{login}» уже занят.");

        Database.Exec(
            @"INSERT INTO Users (Login,PasswordHash,FullName,Email,RoleId)
              VALUES (@l,@p,@f,@e,@r)",
            cmd =>
            {
                cmd.Parameters.AddWithValue("@l", login.Trim());
                cmd.Parameters.AddWithValue("@p", BCrypt.Net.BCrypt.HashPassword(password));
                cmd.Parameters.AddWithValue("@f", fullName.Trim());
                cmd.Parameters.AddWithValue("@e", email.Trim());
                cmd.Parameters.AddWithValue("@r", isAdmin ? 1 : 2);
            }, isProc: false);
    }

    public void Update(int id, string login, string fullName, string email,
                       bool isAdmin, bool isActive, string? newPassword = null)
    {
        var hash = string.IsNullOrEmpty(newPassword)
            ? null
            : BCrypt.Net.BCrypt.HashPassword(newPassword);

        var sql = hash != null
            ? @"UPDATE Users SET Login=@l,FullName=@f,Email=@e,
                    RoleId=@r,IsActive=@a,PasswordHash=@p WHERE Id=@id"
            : @"UPDATE Users SET Login=@l,FullName=@f,Email=@e,
                    RoleId=@r,IsActive=@a WHERE Id=@id";

        Database.Exec(sql, cmd =>
        {
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@l", login.Trim());
            cmd.Parameters.AddWithValue("@f", fullName.Trim());
            cmd.Parameters.AddWithValue("@e", email.Trim());
            cmd.Parameters.AddWithValue("@r", isAdmin ? 1 : 2);
            cmd.Parameters.AddWithValue("@a", isActive);
            if (hash != null)
                cmd.Parameters.AddWithValue("@p", hash);
        }, isProc: false);
    }

    public void Delete(int id)
    {
        if (id == CurrentUser?.Id)
            throw new InvalidOperationException("Нельзя удалить себя.");
        Database.Exec("DELETE FROM Users WHERE Id=@id",
            cmd => cmd.Parameters.AddWithValue("@id", id), isProc: false);
    }
}

// ═══════════════════════════════════════════════════════════
// CategoryService
// ═══════════════════════════════════════════════════════════
public class CategoryService
{
    private static Category Map(SqlDataReader r) => new()
    {
        Id = r.Int("Id"),
        Name = r.Str("Name"),
        Description = r.Str("Description"),
        SortOrder = r.Int("SortOrder"),
        IsActive = r.Bool("IsActive"),
    };

    public List<Category> GetAll(bool includeInactive = false) =>
        Database.Query(
            "SELECT * FROM Categories" +
            (includeInactive ? "" : " WHERE IsActive=1") +
            " ORDER BY SortOrder, Name", Map);

    public void Create(string name, string description, int sortOrder)
    {
        Database.Exec(
            @"INSERT INTO Categories (Name,Description,SortOrder)
              VALUES (@n,@d,@s)",
            cmd =>
            {
                cmd.Parameters.AddWithValue("@n", name.Trim());
                cmd.Parameters.AddWithValue("@d", description.Trim());
                cmd.Parameters.AddWithValue("@s", sortOrder);
            }, isProc: false);
    }

    public void Update(int id, string name, string description,
                       int sortOrder, bool isActive)
    {
        Database.Exec(
            @"UPDATE Categories SET Name=@n,Description=@d,
              SortOrder=@s,IsActive=@a WHERE Id=@id",
            cmd =>
            {
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@n", name.Trim());
                cmd.Parameters.AddWithValue("@d", description.Trim());
                cmd.Parameters.AddWithValue("@s", sortOrder);
                cmd.Parameters.AddWithValue("@a", isActive);
            }, isProc: false);
    }

    public void Delete(int id)
    {
        int used = Database.Scalar<int>(
            "SELECT COUNT(*) FROM Products WHERE CategoryId=@id AND IsActive=1",
            cmd => cmd.Parameters.AddWithValue("@id", id));
        if (used > 0)
            throw new InvalidOperationException(
                $"Нельзя удалить: в категории {used} активных товаров.");
        Database.Exec("DELETE FROM Categories WHERE Id=@id",
            cmd => cmd.Parameters.AddWithValue("@id", id), isProc: false);
    }
}

// ═══════════════════════════════════════════════════════════
// ProductService
// ═══════════════════════════════════════════════════════════
public class ProductService
{
    private static Product Map(SqlDataReader r) => new()
    {
        Id = r.Int("Id"),
        CategoryId = r.Int("CategoryId"),
        CategoryName = r.Str("CategoryName"),
        Name = r.Str("Name"),
        Description = r.Str("Description"),
        Sku = r.Str("Sku"),
        Price = r.Dec("Price"),
        Stock = r.Int("Stock"),
        ImagePath = r.Str("ImagePath"),
        IsActive = r.Bool("IsActive"),
        StockStatus = r.Str("StockStatus"),
    };

    public List<Product> Search(string? query = null, int? categoryId = null,
                                 bool includeInactive = false) =>
        Database.Query("sp_SearchProducts", Map,
            cmd =>
            {
                cmd.Parameters.AddWithValue("@Query",
                    string.IsNullOrWhiteSpace(query) ? DBNull.Value : (object)query);
                cmd.Parameters.AddWithValue("@CategoryId",
                    categoryId.HasValue ? (object)categoryId.Value : DBNull.Value);
                cmd.Parameters.AddWithValue("@ShowAll", includeInactive ? 1 : 0);
            }, isProc: true);

    public Product? GetById(int id) =>
        Database.Query(
            "SELECT * FROM vw_Products WHERE Id=@id",
            Map, cmd => cmd.Parameters.AddWithValue("@id", id))
        .FirstOrDefault();

    public void Create(string name, string sku, int categoryId,
                       decimal price, int stock, string description,
                       string imagePath)
    {
        Database.Exec(
            @"INSERT INTO Products
              (CategoryId,Name,Description,Sku,Price,Stock,ImagePath)
              VALUES (@c,@n,@d,@s,@p,@st,@img)",
            cmd =>
            {
                cmd.Parameters.AddWithValue("@c", categoryId);
                cmd.Parameters.AddWithValue("@n", name.Trim());
                cmd.Parameters.AddWithValue("@d", description.Trim());
                cmd.Parameters.AddWithValue("@s", sku.Trim());
                cmd.Parameters.AddWithValue("@p", price);
                cmd.Parameters.AddWithValue("@st", stock);
                cmd.Parameters.AddWithValue("@img", imagePath.Trim());
            }, isProc: false);
    }

    public void Update(int id, string name, string sku, int categoryId,
                       decimal price, int stock, string description,
                       string imagePath, bool isActive)
    {
        Database.Exec(
            @"UPDATE Products SET CategoryId=@c,Name=@n,Description=@d,
              Sku=@s,Price=@p,Stock=@st,ImagePath=@img,IsActive=@a
              WHERE Id=@id",
            cmd =>
            {
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@c", categoryId);
                cmd.Parameters.AddWithValue("@n", name.Trim());
                cmd.Parameters.AddWithValue("@d", description.Trim());
                cmd.Parameters.AddWithValue("@s", sku.Trim());
                cmd.Parameters.AddWithValue("@p", price);
                cmd.Parameters.AddWithValue("@st", stock);
                cmd.Parameters.AddWithValue("@img", imagePath.Trim());
                cmd.Parameters.AddWithValue("@a", isActive);
            }, isProc: false);
    }

    public void SoftDelete(int id) =>
        Database.Exec("UPDATE Products SET IsActive=0 WHERE Id=@id",
            cmd => cmd.Parameters.AddWithValue("@id", id), isProc: false);

    public DashboardStats GetStats()
    {
        var stats = Database.Query("sp_GetDashboardStats",
            r => new DashboardStats
            {
                TotalOrders = r.Int("TotalOrders"),
                NewOrders = r.Int("NewOrders"),
                TotalRevenue = r.Dec("TotalRevenue"),
                ActiveProducts = r.Int("ActiveProducts"),
                OutOfStockProducts = r.Int("OutOfStockProducts"),
                ActiveCategories = r.Int("ActiveCategories"),
                ActiveUsers = r.Int("ActiveUsers"),
            }, isProc: true).FirstOrDefault();
        return stats ?? new DashboardStats();
    }
}

// ═══════════════════════════════════════════════════════════
// OrderService
// ═══════════════════════════════════════════════════════════
public class OrderService
{
    private static Order MapOrder(SqlDataReader r) => new()
    {
        Id = r.Int("Id"),
        UserId = r.NullInt("UserId"),
        ClientName = r.Str("ClientName"),
        ClientPhone = r.Str("ClientPhone"),
        ClientEmail = r.Str("ClientEmail"),
        Address = r.Str("Address"),
        Comment = r.Str("Comment"),
        Status = r.Int("Status"),
        StatusLabel = r.Str("StatusLabel"),
        CreatedAt = r.DT("CreatedAt"),
        Total = r.Dec("Total"),
        ItemCount = r.Int("ItemCount"),
    };

    public List<Order> GetAll(int? statusFilter = null)
    {
        var sql = "SELECT * FROM vw_Orders" +
                  (statusFilter.HasValue ? " WHERE Status=@s" : "") +
                  " ORDER BY CreatedAt DESC";
        return Database.Query(sql, MapOrder,
            cmd =>
            {
                if (statusFilter.HasValue)
                    cmd.Parameters.AddWithValue("@s", statusFilter.Value);
            });
    }

    public Order? GetById(int id) =>
        Database.Query("SELECT * FROM vw_Orders WHERE Id=@id",
            MapOrder, cmd => cmd.Parameters.AddWithValue("@id", id))
        .FirstOrDefault();

    public List<OrderItem> GetItems(int orderId) =>
        Database.Query(
            @"SELECT oi.*, p.Name AS ProductName
              FROM OrderItems oi
              JOIN Products p ON p.Id = oi.ProductId
              WHERE oi.OrderId=@id",
            r => new OrderItem
            {
                Id = r.Int("Id"),
                OrderId = r.Int("OrderId"),
                ProductId = r.Int("ProductId"),
                ProductName = r.Str("ProductName"),
                Quantity = r.Int("Quantity"),
                UnitPrice = r.Dec("UnitPrice"),
            },
            cmd => cmd.Parameters.AddWithValue("@id", orderId));

    public int Create(Order order, List<CartItem> cart, int? userId)
    {
        var xml = new XElement("items",
            cart.Select(ci =>
                new XElement("item",
                    new XAttribute("productId", ci.Product.Id),
                    new XAttribute("quantity", ci.Quantity))));

        using var conn = Database.Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "sp_CreateOrder";
        cmd.CommandType = System.Data.CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@ClientName", order.ClientName);
        cmd.Parameters.AddWithValue("@ClientPhone", order.ClientPhone);
        cmd.Parameters.AddWithValue("@ClientEmail", order.ClientEmail);
        cmd.Parameters.AddWithValue("@Address", order.Address);
        cmd.Parameters.AddWithValue("@Comment", order.Comment);
        cmd.Parameters.AddWithValue("@UserId",
            userId.HasValue ? (object)userId.Value : DBNull.Value);
        cmd.Parameters.AddWithValue("@ItemsXml", xml.ToString());

        var outParam = cmd.Parameters.Add("@NewOrderId", System.Data.SqlDbType.Int);
        outParam.Direction = System.Data.ParameterDirection.Output;

        cmd.ExecuteNonQuery();
        return (int)outParam.Value;
    }

    public void UpdateStatus(int orderId, int status) =>
        Database.Exec("sp_UpdateOrderStatus",
            cmd =>
            {
                cmd.Parameters.AddWithValue("@OrderId", orderId);
                cmd.Parameters.AddWithValue("@Status", status);
            }, isProc: true);

    public List<(string Month, decimal Revenue)> GetMonthlyRevenue(int months = 6) =>
        Database.Query("sp_GetMonthlyRevenue",
            r => (r.Str("Month"), r.Dec("Revenue")),
            cmd => cmd.Parameters.AddWithValue("@Months", months),
            isProc: true);
}

// ═══════════════════════════════════════════════════════════
// CartService — in-memory, без БД
// ═══════════════════════════════════════════════════════════
public class CartService
{
    private readonly List<CartItem> _items = new();

    public IReadOnlyList<CartItem> Items => _items.AsReadOnly();
    public int Count => _items.Sum(i => i.Quantity);
    public decimal Total => _items.Sum(i => i.Subtotal);
    public bool IsEmpty => !_items.Any();
    public string TotalFormatted => $"{Total:N2} {StoreConfig.CurrencySymbol}";

    public void Add(Product product, int qty = 1)
    {
        var ex = _items.FirstOrDefault(i => i.Product.Id == product.Id);
        if (ex != null) ex.Quantity += qty;
        else _items.Add(new CartItem { Product = product, Quantity = qty });
        CartChanged?.Invoke();
    }

    public void Remove(int productId)
    {
        _items.RemoveAll(i => i.Product.Id == productId);
        CartChanged?.Invoke();
    }

    public void SetQuantity(int productId, int qty)
    {
        var item = _items.FirstOrDefault(i => i.Product.Id == productId);
        if (item == null) return;
        if (qty <= 0) Remove(productId);
        else { item.Quantity = qty; CartChanged?.Invoke(); }
    }

    public void Clear() { _items.Clear(); CartChanged?.Invoke(); }

    public event Action? CartChanged;
}
