using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace TechStore.Helpers;

/// <summary>bool → Visibility</summary>
public class BoolToVisibilityConverter : IValueConverter
{
    public object Convert(object v, Type t, object p, CultureInfo c) =>
        v is true ? Visibility.Visible : Visibility.Collapsed;
    public object ConvertBack(object v, Type t, object p, CultureInfo c) =>
        v is Visibility.Visible;
}

/// <summary>Инвертированный bool → Visibility</summary>
public class InverseBoolToVisibilityConverter : IValueConverter
{
    public object Convert(object v, Type t, object p, CultureInfo c) =>
        v is true ? Visibility.Collapsed : Visibility.Visible;
    public object ConvertBack(object v, Type t, object p, CultureInfo c) =>
        v is not Visibility.Visible;
}

/// <summary>int (Cart Count) → текст</summary>
public class CartCountConverter : IValueConverter
{
    public object Convert(object v, Type t, object p, CultureInfo c) =>
        v is int n && n > 0 ? n.ToString() : "";
    public object ConvertBack(object v, Type t, object p, CultureInfo c) => 0;
}

/// <summary>int > 0 → Visible</summary>
public class PositiveToVisibilityConverter : IValueConverter
{
    public object Convert(object v, Type t, object p, CultureInfo c) =>
        v is int n && n > 0 ? Visibility.Visible : Visibility.Collapsed;
    public object ConvertBack(object v, Type t, object p, CultureInfo c) => 0;
}

/// <summary>
/// int Status (0-4) → цветная кисть.
/// 0=Новый, 1=В обработке, 2=Отправлен, 3=Доставлен, 4=Отменён
/// </summary>
public class StatusToBrushConverter : IValueConverter
{
    public object Convert(object v, Type t, object p, CultureInfo c)
    {
        if (v is int s)
            return s switch
            {
                0 => new SolidColorBrush(Color.FromRgb(21,  101, 192)),  // Новый — синий
                1 => new SolidColorBrush(Color.FromRgb(245, 127,  23)),  // В обработке — оранж
                2 => new SolidColorBrush(Color.FromRgb(106,  27, 154)),  // Отправлен — фиолет
                3 => new SolidColorBrush(Color.FromRgb( 46, 125,  50)),  // Доставлен — зелёный
                4 => new SolidColorBrush(Color.FromRgb(198,  40,  40)),  // Отменён — красный
                _ => Brushes.Gray,
            };
        return Brushes.Gray;
    }
    public object ConvertBack(object v, Type t, object p, CultureInfo c) => 0;
}

/// <summary>bool IsActive → цвет текста (зелёный/красный)</summary>
public class ActiveToColorConverter : IValueConverter
{
    public object Convert(object v, Type t, object p, CultureInfo c) =>
        v is true
            ? new SolidColorBrush(Color.FromRgb(46, 125, 50))
            : new SolidColorBrush(Color.FromRgb(198, 40, 40));
    public object ConvertBack(object v, Type t, object p, CultureInfo c) => true;
}

/// <summary>bool IsActive → "Активен" / "Отключён"</summary>
public class ActiveToStringConverter : IValueConverter
{
    public object Convert(object v, Type t, object p, CultureInfo c) =>
        v is true ? "Активен" : "Отключён";
    public object ConvertBack(object v, Type t, object p, CultureInfo c) => true;
}

/// <summary>decimal → форматированная цена</summary>
public class PriceConverter : IValueConverter
{
    public object Convert(object v, Type t, object p, CultureInfo c) =>
        v is decimal d ? $"{d:N2} {StoreConfig.CurrencySymbol}" : "—";
    public object ConvertBack(object v, Type t, object p, CultureInfo c) =>
        decimal.TryParse(
            v?.ToString()?.Replace(StoreConfig.CurrencySymbol, "").Trim(),
            out var r) ? r : 0m;
}
